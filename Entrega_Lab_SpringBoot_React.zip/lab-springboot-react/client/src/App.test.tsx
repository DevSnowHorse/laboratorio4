import React from 'react';
import { render, screen } from '@testing-library/react';
import App from './App';

test('muestra los carros que devuelve la API', async () => {
  // Simula la respuesta de la API (y de GIPHY) sin levantar el backend
  global.fetch = jest.fn(() => Promise.resolve({
    ok: true,
    json: () => Promise.resolve([
      { id: 1, name: 'Ferrari', model: 'F8 Tributo', color: 'Rojo', modelYear: 2021, price: 276000 },
    ]),
  })) as jest.Mock;

  render(<App />);

  expect(await screen.findByText('Ferrari')).toBeInTheDocument();
  expect(screen.getByText('F8 Tributo')).toBeInTheDocument();
  expect(global.fetch).toHaveBeenCalledWith('http://localhost:8080/api/cars');
});
