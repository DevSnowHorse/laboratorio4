import React, { useState, useEffect, useRef } from 'react';
import { Car } from './Car';

interface CarFormProps {
  car: Car;
  onSave: (car: Car) => Promise<void>;
  onCancel: () => void;
}

const CarForm: React.FC<CarFormProps> = ({ car, onSave, onCancel }) => {

  // Los campos se guardan como texto mientras se editan
  const [form, setForm] = useState({
    name: car.name,
    model: car.model ?? '',
    color: car.color ?? '',
    modelYear: car.modelYear?.toString() ?? '',
    price: car.price?.toString() ?? '',
  });
  const [error, setError] = useState<string>('');
  const [saving, setSaving] = useState<boolean>(false);
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }, []);

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = event.target;
    setForm({ ...form, [name]: value });
  };

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    setSaving(true);

    onSave({
      id: car.id,
      name: form.name.trim(),
      model: form.model.trim(),
      color: form.color.trim(),
      modelYear: form.modelYear ? Number(form.modelYear) : null,
      price: form.price ? Number(form.price) : null,
    }).catch(e => {
      setError('No se pudo guardar: ' + e.message);
      setSaving(false);
    });
  };

  const isNew = car.id === undefined;

  return (
    <form className="car-form" ref={formRef} onSubmit={handleSubmit}>
      <h3>{isNew ? 'Nuevo carro (POST)' : 'Editar carro #' + car.id + ' (PUT)'}</h3>
      <div className="fields">
        <label>Marca *
          <input name="name" value={form.name} onChange={handleChange} required />
        </label>
        <label>Modelo
          <input name="model" value={form.model} onChange={handleChange} />
        </label>
        <label>Color
          <input name="color" value={form.color} onChange={handleChange} />
        </label>
        <label>Año
          <input name="modelYear" type="number" min="1886" max="2100" value={form.modelYear} onChange={handleChange} />
        </label>
        <label>Precio (USD)
          <input name="price" type="number" min="0" step="any" value={form.price} onChange={handleChange} />
        </label>
      </div>
      {error && <p className="error">{error}</p>}
      <div className="actions">
        <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Guardando...' : 'Guardar'}</button>
        <button type="button" className="btn" onClick={onCancel}>Cancelar</button>
      </div>
    </form>
  );
};

export default CarForm;
