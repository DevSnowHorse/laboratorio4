import * as React from 'react';
import './App.css';
import CarList from './CarList';
import logo from './logo.svg';

class App extends React.Component<{}, any> {

  render() {

    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Cool Cars</h1>
          <span className="App-subtitle">Spring Boot + React</span>
        </header>

        <main className="App-main">
          <CarList/>
        </main>
      </div>

    );
  }

}

export default App;
