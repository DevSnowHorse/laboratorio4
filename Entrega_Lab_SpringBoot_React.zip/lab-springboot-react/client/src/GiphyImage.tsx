import React, { useState, useEffect } from 'react';

interface GiphyImageProps {
  name: string;
}

// GIF por defecto cuando no hay resultados (o no hay API Key)
const DEFAULT_GIF = '//media.giphy.com/media/YaOxRsmrv9IeA/giphy.gif';

const GiphyImage: React.FC<GiphyImageProps> = ({ name }) => {

  const [giphyUrl, setGiphyUrl] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  useEffect(() => {

    // La API Key se lee del archivo .env.local (REACT_APP_GIPHY_API_KEY)
    const giphyApi = '//api.giphy.com/v1/gifs/search?api_key='
      + process.env.REACT_APP_GIPHY_API_KEY + '&limit=1&q=';

    setIsLoading(true);

    fetch(giphyApi + encodeURIComponent(name))
      .then(response => response.json())
      .then(response => {

        if (response.data && response.data.length > 0) {
          setGiphyUrl(response.data[0].images.original.url);
        } else {
          // cuando no se encuentran imágenes
          setGiphyUrl(DEFAULT_GIF);
        }

        setIsLoading(false);
      })
      .catch(() => {
        setGiphyUrl(DEFAULT_GIF);
        setIsLoading(false);
      });

  }, [name]);

  if (isLoading) {
    return <p>Loading image...</p>;
  }

  if (!giphyUrl) {
    return null;
  }

  return (
    <img src={giphyUrl} alt={name} width="200" loading="lazy" />
  );
};

export default GiphyImage;
