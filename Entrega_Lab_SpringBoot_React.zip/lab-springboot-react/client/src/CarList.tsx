import React, { useState, useEffect, useCallback } from 'react';
import GiphyImage from './GiphyImage';
import CarForm from './CarForm';
import { API_URL, Car, emptyCar } from './Car';

const priceFormat = new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 });

const CarList: React.FC = () => {

  const [cars, setCars] = useState<Car[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');
  const [onlyCool, setOnlyCool] = useState<boolean>(false);
  const [editing, setEditing] = useState<Car | null>(null);

  const loadCars = useCallback(() => {
    setIsLoading(true);

    fetch(API_URL + (onlyCool ? '/cool-cars' : '/api/cars'))
      .then(response => response.json())
      .then(data => {
        setCars(data);
        setError('');
        setIsLoading(false);
      })
      .catch(() => {
        setError('No se pudo conectar con la API en ' + API_URL);
        setIsLoading(false);
      });

  }, [onlyCool]);

  useEffect(() => {
    loadCars();
  }, [loadCars]);

  // POST si el carro es nuevo (no tiene id), PUT si ya existe
  const saveCar = (car: Car) => {
    const isNew = car.id === undefined;

    return fetch(API_URL + '/api/cars' + (isNew ? '' : '/' + car.id), {
      method: isNew ? 'POST' : 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(car),
    }).then(response => {
      if (!response.ok) {
        throw new Error('la API respondió ' + response.status);
      }
      setEditing(null);
      loadCars();
    });
  };

  // "Loading..." solo en la primera carga, para no recargar todos los GIFs al guardar
  if (isLoading && cars.length === 0) {
    return <p>Loading...</p>;
  }

  return (
    <div>
      <div className="toolbar">
        <h2>Car List</h2>
        <label>
          <input type="checkbox" checked={onlyCool} onChange={e => setOnlyCool(e.target.checked)} />
          {' '}Solo cool cars
        </label>
        <button className="btn btn-primary" onClick={() => setEditing({ ...emptyCar })}>+ Nuevo carro</button>
      </div>

      {error && <p className="error">{error}</p>}

      {editing &&
        <CarForm key={editing.id ?? 'nuevo'} car={editing} onSave={saveCar} onCancel={() => setEditing(null)}/>
      }

      <div className="car-grid">
        {cars.map((car: Car) =>
          <div className="car-card" key={car.id}>
            <GiphyImage name={car.name}/>
            <div className="car-info">
              <h3>{car.name}</h3>
              <p className="car-model">{car.model || '—'}</p>
              <dl>
                <dt>Color</dt><dd>{car.color || '—'}</dd>
                <dt>Año</dt><dd>{car.modelYear ?? '—'}</dd>
                <dt>Precio</dt><dd>{car.price != null ? priceFormat.format(car.price) : '—'}</dd>
              </dl>
              <button className="btn" onClick={() => setEditing(car)}>Editar</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CarList;
