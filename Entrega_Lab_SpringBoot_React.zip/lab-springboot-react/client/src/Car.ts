export interface Car {
  id?: number;
  name: string;
  model: string | null;
  color: string | null;
  modelYear: number | null;
  price: number | null;
}

export const API_URL = 'http://localhost:8080';

export const emptyCar: Car = { name: '', model: '', color: '', modelYear: null, price: null };
