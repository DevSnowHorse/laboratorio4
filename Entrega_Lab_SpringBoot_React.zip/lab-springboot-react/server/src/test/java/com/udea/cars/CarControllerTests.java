package com.udea.cars;

import static org.hamcrest.Matchers.notNullValue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class CarControllerTests {

    @Autowired
    private MockMvc mvc;

    @Test
    void postCreaUnCarro() throws Exception {
        mvc.perform(post("/api/cars")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"Tesla\",\"model\":\"Model S\",\"color\":\"Negro\",\"modelYear\":2023,\"price\":89990}"))
                .andExpect(status().isCreated())
                .andExpect(header().string("Location", notNullValue()))
                .andExpect(jsonPath("$.id").isNumber())
                .andExpect(jsonPath("$.name").value("Tesla"))
                .andExpect(jsonPath("$.modelYear").value(2023));
    }

    @Test
    void postSinNombreDevuelve400() throws Exception {
        mvc.perform(post("/api/cars")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"model\":\"Sin nombre\"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void putActualizaUnCarro() throws Exception {
        mvc.perform(put("/api/cars/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"Ferrari\",\"model\":\"Roma\",\"color\":\"Negro\",\"modelYear\":2023,\"price\":222000}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.model").value("Roma"))
                .andExpect(jsonPath("$.color").value("Negro"));
    }

    @Test
    void putDeCarroInexistenteDevuelve404() throws Exception {
        mvc.perform(put("/api/cars/9999")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"Fantasma\"}"))
                .andExpect(status().isNotFound());
    }
}
