package com.udea.cars;

import java.net.URI;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
// A nivel de clase para que aplique también a POST y PUT (http y https del cliente React)
@CrossOrigin(origins = {"http://localhost:3000", "https://localhost:3000"})
public class CarController {
    private CarRepository repository;

    public CarController(CarRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/cool-cars")
    public Collection<Car> coolCars() {
        return repository.findAll().stream()
                .filter(this::isCool)
                .collect(Collectors.toList());
    }

    // Todos los carros, ordenados por id
    @GetMapping("/api/cars")
    public List<Car> allCars() {
        return repository.findAll(Sort.by("id"));
    }

    // POST: crea un carro nuevo y responde 201 Created con el carro guardado
    @PostMapping("/api/cars")
    public ResponseEntity<Car> createCar(@RequestBody Car car) {
        if (isBlank(car.getName())) {
            return ResponseEntity.badRequest().build();
        }
        car.setId(null); // el id siempre lo genera la base de datos
        Car saved = repository.save(car);
        return ResponseEntity.created(URI.create("/api/cars/" + saved.getId())).body(saved);
    }

    // PUT: actualiza todos los datos de un carro existente (404 si no existe)
    @PutMapping("/api/cars/{id}")
    public ResponseEntity<Car> updateCar(@PathVariable Long id, @RequestBody Car car) {
        if (isBlank(car.getName())) {
            return ResponseEntity.badRequest().build();
        }
        return repository.findById(id)
                .map(existing -> {
                    existing.setName(car.getName());
                    existing.setModel(car.getModel());
                    existing.setColor(car.getColor());
                    existing.setModelYear(car.getModelYear());
                    existing.setPrice(car.getPrice());
                    return ResponseEntity.ok(repository.save(existing));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    private boolean isCool(Car car) {
        return !car.getName().equals("AMC Gremlin") &&
                !car.getName().equals("Triumph Stag") &&
                !car.getName().equals("Ford Pinto") &&
                !car.getName().equals("Yugo GV");
    }

    private boolean isBlank(String text) {
        return text == null || text.trim().isEmpty();
    }
}
