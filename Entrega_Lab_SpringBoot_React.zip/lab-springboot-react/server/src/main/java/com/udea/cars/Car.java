package com.udea.cars;

import java.io.Serializable;
import lombok.*;

import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.Entity;

@Entity
@Data
@NoArgsConstructor
@ToString
public class Car implements Serializable {
    @Id @GeneratedValue
    private Long id;
    private @NonNull String name;
    private String model;
    private String color;
    // "year" es palabra reservada en H2 2.x, por eso el atributo se llama modelYear
    private Integer modelYear;
    private Double price;

    public Car(String name, String model, String color, Integer modelYear, Double price) {
        this.name = name;
        this.model = model;
        this.color = color;
        this.modelYear = modelYear;
        this.price = price;
    }
}
