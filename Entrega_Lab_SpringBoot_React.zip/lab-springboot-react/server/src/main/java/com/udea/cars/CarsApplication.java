package com.udea.cars;

import java.util.stream.Stream;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class CarsApplication {

    public static void main(String[] args) {
        SpringApplication.run(CarsApplication.class, args);
    }

    @Bean
    ApplicationRunner init(CarRepository repository) {
        return args -> {
            Stream.of(
                    new Car("Ferrari", "F8 Tributo", "Rojo", 2021, 276000.0),
                    new Car("Jaguar Car", "F-Type R", "Verde", 2020, 103000.0),
                    new Car("Porsche", "911 Carrera S", "Plata", 2022, 131000.0),
                    new Car("Lamborghini", "Huracán EVO", "Amarillo", 2021, 261000.0),
                    new Car("Bugatti", "Chiron", "Azul", 2019, 3000000.0),
                    new Car("AMC Gremlin", "X", "Naranja", 1974, 2500.0),
                    new Car("Triumph Stag", "Mk II", "Blanco", 1975, 18000.0),
                    new Car("Ford Pinto", "Runabout", "Café", 1976, 3500.0),
                    new Car("Yugo GV", "GV Plus", "Rojo", 1988, 4000.0)
            ).forEach(repository::save);
            repository.findAll().forEach(System.out::println);
        };
    }

}
