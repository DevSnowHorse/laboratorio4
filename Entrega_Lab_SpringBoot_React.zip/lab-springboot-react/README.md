# Laboratorio: Introducción a Spring Boot con React

Tecnológico de Antioquia · 2026

Aplicación "Cool Cars": API REST en Spring Boot (`server`) y cliente React + TypeScript (`client`).
Incluye el ejercicio: más datos por vehículo (modelo, color, año, precio) y los métodos POST y PUT consumidos desde React.

## Requisitos

- JDK 8 o superior
- Maven 3.6+ (o usar el wrapper `mvnw` incluido, que descarga Maven solo)
- Node.js 18 o superior (probado con 22.23.2) y npm

## 1. Backend (puerto 8080)

**NetBeans:** Archivo → Abrir proyecto → carpeta `server` → clic derecho → Run
(el archivo `nbactions.xml` hace que Run ejecute `spring-boot:run`).

> Desarrollado con **NetBeans 8.2**. Esa versión trae Maven 3.0.5, que no sirve para Spring Boot 2.7:
> configurar Maven 3.6+ en Herramientas → Opciones → Java → Maven → *Maven Home*.
> En Apache NetBeans 12 o superior no hace falta.

**Terminal:**

```
cd server
mvnw spring-boot:run
```

Al arrancar carga 9 carros de prueba en la base H2 en memoria.

| URL | Qué muestra |
|---|---|
| http://localhost:8080 | HAL Explorer (recursos de Spring Data REST) |
| http://localhost:8080/cool-cars | GET: los 5 carros "cool" |
| http://localhost:8080/api/cars | GET: todos los carros |
| POST http://localhost:8080/api/cars | Crea un carro (JSON) → 201 Created |
| PUT http://localhost:8080/api/cars/{id} | Actualiza un carro (JSON) → 200 OK / 404 |
| http://localhost:8080/h2-console | Consola H2 · JDBC URL `jdbc:h2:mem:testdb` · usuario `sa` · sin contraseña |

Pruebas: `mvnw test`.

## 2. Frontend (puerto 3000)

1. Copiar `client/.env.local.example` como `client/.env.local` y poner una API Key de GIPHY
   (https://developers.giphy.com/dashboard). Sin clave la app funciona, pero todos los carros
   muestran el GIF por defecto.
2. Instalar dependencias y arrancar (con el backend ya corriendo):

```
cd client
npm install
npm start
```

3. Abrir **https://localhost:3000**. El navegador avisa que la conexión no es privada porque el
   certificado (`cert.pem` / `key.pem`, generado con OpenSSL según la guía) es autofirmado:
   Avanzado → Continuar a localhost.

Para usar HTTP en vez de HTTPS, borrar el archivo `client/.env`.

## 3. Build de producción (PWA)

```
cd client
yarn build
serve -s build -p 3000
```

Luego abrir http://localhost:3000.
